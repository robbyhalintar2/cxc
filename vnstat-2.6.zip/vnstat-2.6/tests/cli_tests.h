#ifndef CLI_TESTS_H
#define CLI_TESTS_H

void add_cli_tests(Suite *s);

#endif
